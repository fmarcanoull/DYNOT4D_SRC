% SD = HOMER2_enPruneChannels(d,SD,tInc,dRange,SNRthresh,SDrange,reset)
%
% UI NAME:
% Prune_Channels
%
%
% Prune channels from the measurement list if their signal is too weak, too
% strong, or their standard deviation is too great. This function
% updates SD.MeasListAct based on whether data 'd' meets these conditions
% as specified by'dRange' and 'SNRthresh'.
%
% INPUTS:
% d - data (nTpts x nChannels )
% SD - data structure describing the probe
% dRange - if mean(d) < dRange(1) or > dRange(2) then it is excluded as an
%      active channel
% SNRthresh - if mean(d)/std(d) < SNRthresh then it is excluded as an
%      active channel
% SDrange - will prune channels with a source-detector separation <
%           SDrange(1) or > SDrange(2)
% reset - reset previously pruned channels (automatic and manual)
%
% OUTPUTS:
% SD - data structure describing the probe
%
% TO DO:
% consider Conc as well as wavelength data
%

function [SD,msg] = HOMER2_enPruneChannels(d,SD,tInc,dRange,SNRthresh,SDrange,resetFlag)


% Preset values
if nargin~=7
    disp( 'USAGE: HOMER2_enPruneChannels(d,SD,tInc,dRange,SNRthresh,resetFlag)' )
    return
end

lstInc = find(tInc==1);
d = d(lstInc,:);

%
if ~isfield(SD,'MeasListAct') | resetFlag==1
    SD.MeasListAct = ones(size(SD.MeasList,1),1);
end

% check for dRange and SNRthresh
dmean = mean(d,1);
dstd = std(d,[],1);

%nLambda = length(SD.Lambda);
%lst1 = find(SD.MeasList(:,4)==1);

idxs1 = [];
idxs2 = [];
idxs3 = [];
nLambda = length(SD.Lambda);
lst1 = find(SD.MeasList(:,4)==1);    

% Start by including all channels
chanList = ones(size(SD.MeasList,1),1);
canalesXlongitudOnda = length(lst1);

msg = [];

f = figure;
axf = axes('Parent',f);
cla(axf);
etiquetaIncluidosExcluidos = {};
for ii = 1:nLambda
    lst = [];
    rhoSD = [];
    for jj = 1:canalesXlongitudOnda
        lst(jj) = find(SD.MeasList(:,1)==SD.MeasList(lst1(jj),1) & ...
                       SD.MeasList(:,2)==SD.MeasList(lst1(jj),2) & ...
                       SD.MeasList(:,4)==ii);
        rhoSD(jj) = norm( SD.SrcPos(SD.MeasList(lst1(jj),1),:) - SD.DetPos(SD.MeasList(lst1(jj),2),:) );
    end
            
    % dRange exclusion criteria
    idxs1 = [idxs1, find(dmean(lst)<=dRange(1) | dmean(lst)>=dRange(2))];
    
    % SNRthresh exclusion criteria
    idxs2 = [idxs2, find((dmean(lst)./dstd(lst)) <= SNRthresh)];

    % SDrange exclusion criteria
    idxs3 = [idxs3, find(rhoSD<SDrange(1) | rhoSD>SDrange(2))];
    
    idxsExcl = unique([idxs1(:)', idxs2(:)', idxs3(:)']);
    idsxIncl = setdiff (1:canalesXlongitudOnda,idxsExcl);
    if ~isempty(idxsExcl)
        msg = [msg, sprintf('Recorte de canales:  excluidos %d canales en total para la longitud de onda  %d:\n',length(idxsExcl) ,ii)];
    end
    
    if ~isempty(idxs1)
        msg = [msg, sprintf('          excluidos según rango [ %s ], los canales [ %s ]  \n', num2str(dRange), num2str(idxs1(:)'))];
    end
    if ~isempty(idxs2)
        msg = [msg, sprintf('          excluidos según umbral de SNR (%0.1f), los canales [ %s ]\n', SNRthresh , num2str(idxs2(:)'))];
    end
    if ~isempty(idxs3)
        msg = [msg, sprintf('          excluidos según rango de distancia [ %s ] los canales [ %s ] \n',  num2str(SDrange), num2str(idxs3(:)'))];
    end
    chanList(lst(idxsExcl)) = 0;


    hold(axf,'on');
    colorPuntosIncluidos = decimalToBinaryVector(ii,3,'LSBFirst')*0.65;
    colorPuntosExcluidos = colorPuntosIncluidos*0.4+0.6;
    h1=plot(rhoSD(idsxIncl),dmean(lst(idsxIncl)),'MarkerFaceColor','none','MarkerEdgeColor',colorPuntosIncluidos,'MarkerSize',8,'Marker','o','LineStyle','none');
    text(rhoSD(idsxIncl),dmean(lst(idsxIncl)),string(num2cell(idsxIncl)),'Color',colorPuntosIncluidos,'FontSize',8);
    h2=plot(rhoSD(idxsExcl),dmean(lst(idxsExcl)),'MarkerFaceColor','none','MarkerEdgeColor',colorPuntosExcluidos,'MarkerSize',8,'Marker','*','LineStyle','none');
    text(rhoSD(idxsExcl),dmean(lst(idxsExcl)),string(num2cell(idxsExcl)),'Color',colorPuntosExcluidos,'FontSize',8);
    etiquetaIncluidosExcluidos = [etiquetaIncluidosExcluidos ['Incluidos (' num2str(SD.Lambda(ii)) ' nm)'] ['Excluidos (' num2str(SD.Lambda(ii)) ' nm)'] ] ;
    
end
    
legend(etiquetaIncluidosExcluidos);
xlabel (axf,'Distancia fuente-detector');
ylabel (axf,'Intensidad media del canal');
hold(axf,'off');

% update SD.MeasListAct
SD.MeasListActAuto = ones(size(SD.MeasList,1),1);
SD.MeasListActAuto(find(chanList==0)) = 0;

SD.MeasListAct(find(chanList==0)) = 0;





